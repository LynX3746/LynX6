﻿saveinstance({decomptype = new})
Saveinstance()
loadstring(game:HttpGetAsync("https://pastebin.com/raw/fPP8bZ8Z"))()