-- Create GUI elements
local player = game.Players.LocalPlayer
local screenGui = Instance.new("ScreenGui")
local speedButton = Instance.new("TextButton")

screenGui.Parent = player:WaitForChild("PlayerGui")
screenGui.Name = "SpeedBoostGUI"

speedButton.Parent = screenGui
speedButton.Text = "Increase Speed"
speedButton.Size = UDim2.new(0, 200, 0, 50) -- Width: 200px, Height: 50px
speedButton.Position = UDim2.new(0.5, -100, 0.5, -25) -- Center the button
speedButton.BackgroundColor3 = Color3.new(0.2, 0.8, 0.2) -- Green color
speedButton.TextColor3 = Color3.new(1, 1, 1) -- White text
speedButton.Font = Enum.Font.SourceSansBold
speedButton.TextSize = 24

local function increaseSpeed()
    local character = player.Character or player.CharacterAdded:Wait()
    local humanoid = character:FindFirstChild("Humanoid")
    if humanoid then
        humanoid.WalkSpeed = humanoid.WalkSpeed + 10 -- Increase speed by 10
    end
end

speedButton.MouseButton1Click:Connect(increaseSpeed)
