-- Specify the name of the part you want to track
local partName = "MyPart" -- Replace with the name of your part
local part = workspace:FindFirstChild(partName)

if part and part:IsA("BasePart") then
    print(partName .. " Position: " .. tostring(part.Position))
else
    warn("Part named '" .. partName .. "' not found in Workspace!")
end
