local player = game.Players.LocalPlayer
local character = player.Character or player.CharacterAdded:Wait()

-- Create GUI Elements
local screenGui = Instance.new("ScreenGui")
local frame = Instance.new("Frame")
local toggleButton = Instance.new("TextButton")
local title = Instance.new("TextLabel")

-- Parent the GUI to the PlayerGui
screenGui.Parent = player:WaitForChild("PlayerGui")
screenGui.Name = "NoclipGUI"

-- Frame Settings
frame.Parent = screenGui
frame.Size = UDim2.new(0, 250, 0, 150)
frame.Position = UDim2.new(0.5, -125, 0.7, -75)
frame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)

-- Title Settings
title.Parent = frame
title.Text = "Noclip Mode"
title.Size = UDim2.new(1, 0, 0.3, 0)
title.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
title.TextColor3 = Color3.fromRGB(255, 255, 255)
title.Font = Enum.Font.SourceSansBold
title.TextSize = 20

-- Button Settings
toggleButton.Parent = frame
toggleButton.Text = "Enable Noclip"
toggleButton.Size = UDim2.new(0.8, 0, 0.4, 0)
toggleButton.Position = UDim2.new(0.1, 0, 0.5, 0)
toggleButton.BackgroundColor3 = Color3.fromRGB(0, 200, 0)
toggleButton.TextColor3 = Color3.fromRGB(255, 255, 255)
toggleButton.Font = Enum.Font.SourceSansBold
toggleButton.TextSize = 18

-- Noclip Variables
local noclipEnabled = false

-- Noclip Functionality
local function toggleNoclip()
    noclipEnabled = not noclipEnabled
    if noclipEnabled then
        toggleButton.Text = "Disable Noclip"
        toggleButton.BackgroundColor3 = Color3.fromRGB(200, 0, 0)
    else
        toggleButton.Text = "Enable Noclip"
        toggleButton.BackgroundColor3 = Color3.fromRGB(0, 200, 0)
    end
end

-- Constantly Check for Noclip
game:GetService("RunService").Stepped:Connect(function()
    if noclipEnabled and character then
        for _, part in pairs(character:GetDescendants()) do
            if part:IsA("BasePart") and part.CanCollide then
                part.CanCollide = false
            end
        end
    end
end)

-- Connect Button Click to Toggle Function
toggleButton.MouseButton1Click:Connect(toggleNoclip)
