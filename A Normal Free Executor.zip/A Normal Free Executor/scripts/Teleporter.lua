--[[To use this on a part or player model first use dex
explorer to get the name of the part or player model
then use my location finder to get the part's location (x, y, z coordinate) then put the xyz coordinates in the gui and ur done
]]
local player = game.Players.LocalPlayer

local screenGui = Instance.new("ScreenGui")
local frame = Instance.new("Frame")
local xInput = Instance.new("TextBox")
local yInput = Instance.new("TextBox")
local zInput = Instance.new("TextBox")
local teleportButton = Instance.new("TextButton")
local title = Instance.new("TextLabel")

screenGui.Parent = player:WaitForChild("PlayerGui")
screenGui.Name = "TeleporterGUI"

frame.Parent = screenGui
frame.Size = UDim2.new(0, 300, 0, 200)
frame.Position = UDim2.new(0.5, -150, 0.5, -100)
frame.BackgroundColor3 = Color3.new(0.2, 0.2, 0.2)

title.Parent = frame
title.Text = "Enter Coordinates"
title.Size = UDim2.new(1, 0, 0.2, 0)
title.BackgroundColor3 = Color3.new(0.3, 0.3, 0.3)
title.TextColor3 = Color3.new(1, 1, 1)
title.Font = Enum.Font.SourceSansBold
title.TextSize = 20

-- X Input
xInput.Parent = frame
xInput.PlaceholderText = "X Coordinate"
xInput.Size = UDim2.new(0.8, 0, 0.2, 0)
xInput.Position = UDim2.new(0.1, 0, 0.3, 0)
xInput.BackgroundColor3 = Color3.new(0.4, 0.4, 0.4)
xInput.TextColor3 = Color3.new(1, 1, 1)
xInput.Font = Enum.Font.SourceSans
xInput.TextSize = 18

-- Y Input
yInput.Parent = frame
yInput.PlaceholderText = "Y Coordinate"
yInput.Size = UDim2.new(0.8, 0, 0.2, 0)
yInput.Position = UDim2.new(0.1, 0, 0.5, 0)
yInput.BackgroundColor3 = Color3.new(0.4, 0.4, 0.4)
yInput.TextColor3 = Color3.new(1, 1, 1)
yInput.Font = Enum.Font.SourceSans
yInput.TextSize = 18

-- Z Input
zInput.Parent = frame
zInput.PlaceholderText = "Z Coordinate"
zInput.Size = UDim2.new(0.8, 0, 0.2, 0)
zInput.Position = UDim2.new(0.1, 0, 0.7, 0)
zInput.BackgroundColor3 = Color3.new(0.4, 0.4, 0.4)
zInput.TextColor3 = Color3.new(1, 1, 1)
zInput.Font = Enum.Font.SourceSans
zInput.TextSize = 18

-- Teleport Button
teleportButton.Parent = frame
teleportButton.Text = "Teleport"
teleportButton.Size = UDim2.new(0.6, 0, 0.2, 0)
teleportButton.Position = UDim2.new(0.2, 0, 0.9, -40)
teleportButton.BackgroundColor3 = Color3.new(0.2, 0.8, 0.2)
teleportButton.TextColor3 = Color3.new(1, 1, 1)
teleportButton.Font = Enum.Font.SourceSansBold
teleportButton.TextSize = 18

-- Teleport functionality
local function teleportPlayer()
    local x = tonumber(xInput.Text)
    local y = tonumber(yInput.Text)
    local z = tonumber(zInput.Text)

    if x and y and z then
        local character = player.Character or player.CharacterAdded:Wait()
        if character and character:FindFirstChild("HumanoidRootPart") then
            character.HumanoidRootPart.CFrame = CFrame.new(x, y, z)
            print("Teleported to:", x, y, z)
        else
            warn("HumanoidRootPart not found!")
        end
    else
        warn("Invalid coordinates! Please enter valid numbers.")
    end
end

teleportButton.MouseButton1Click:Connect(teleportPlayer)
