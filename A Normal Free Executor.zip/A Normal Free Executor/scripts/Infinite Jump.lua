local Player = game.Players.LocalPlayer
local UIS = game:GetService("UserInputService")

local InfiniteJumpEnabled = true

UIS.InputBegan:Connect(function(input, gameProcessed)
    if not gameProcessed and input.KeyCode == Enum.KeyCode.Space then
        if InfiniteJumpEnabled then
            local character = Player.Character
            if character and character:FindFirstChild("Humanoid") then
                character.Humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
            end
        end
    end
end)
