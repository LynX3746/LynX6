-- Create GUI elements
local player = game.Players.LocalPlayer
local screenGui = Instance.new("ScreenGui")
local jumpButton = Instance.new("TextButton")

-- Parent the ScreenGui to the player's PlayerGui
screenGui.Parent = player:WaitForChild("PlayerGui")
screenGui.Name = "JumpBoostGUI"

jumpButton.Parent = screenGui
jumpButton.Text = "Increase Jump Power"
jumpButton.Size = UDim2.new(0, 250, 0, 50) -- Width: 250px, Height: 50px
jumpButton.Position = UDim2.new(0.5, -125, 0.6, -25) -- Center the button
jumpButton.BackgroundColor3 = Color3.new(0.2, 0.2, 0.8) -- Blue color
jumpButton.TextColor3 = Color3.new(1, 1, 1) -- White text
jumpButton.Font = Enum.Font.SourceSansBold
jumpButton.TextSize = 24

local function increaseJumpPower()
    local character = player.Character or player.CharacterAdded:Wait()
    local humanoid = character:FindFirstChild("Humanoid")
    if humanoid then
        humanoid.JumpPower = humanoid.JumpPower + 10 -- Increase jump power by 10
    end
end

jumpButton.MouseButton1Click:Connect(increaseJumpPower)
